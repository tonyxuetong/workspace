package lulu.magiccube;

import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLDecoder;
import java.util.LinkedHashMap;
import java.util.Map;

import com.wowza.wms.amf.AMFPacket;
import com.wowza.wms.application.IApplicationInstance;
import com.wowza.wms.application.WMSProperties;
import com.wowza.wms.media.model.MediaCodecInfoAudio;
import com.wowza.wms.media.model.MediaCodecInfoVideo;
import com.wowza.wms.module.IModuleOnStream;
import com.wowza.wms.module.ModuleBase;
import com.wowza.wms.stream.IMediaStream;
import com.wowza.wms.stream.IMediaStreamActionNotify3;


public class CustomListnerModule extends ModuleBase implements IModuleOnStream
{

	private static final String USER_AGENT = "Mozilla/5.0";
	//to do change on static ip
	private static final String URL_START = "http://ec2-52-196-239-12.ap-northeast-1.compute.amazonaws.com:3000/api/wowza/stream_start";
	private static final String URL_STOP = "http://ec2-52-196-239-12.ap-northeast-1.compute.amazonaws.com:3000/api/wowza/stream_stop";
		
	IApplicationInstance appInstance = null;
	
	class StreamListener implements IMediaStreamActionNotify3
	{
		public void onMetaData(IMediaStream stream, AMFPacket metaDataPacket)
		{
			System.out.println("onMetaData[" + stream.getContextStr() + "]: " + metaDataPacket.toString());
		}

		public void onPauseRaw(IMediaStream stream, boolean isPause, double location)
		{
			System.out.println("onPauseRaw[" + stream.getContextStr() + "]: isPause:" + isPause + " location:" + location);
		}

		public void onPause(IMediaStream stream, boolean isPause, double location)
		{
			System.out.println("onPause[" + stream.getContextStr() + "]: isPause:" + isPause + " location:" + location);
		}

		public void onPlay(IMediaStream stream, String streamName, double playStart, double playLen, int playReset)
		{
			System.out.println("onPlay[" + stream.getContextStr() + "]: playStart:" + playStart + " playLen:" + playLen + " playReset:" + playReset);
		}

		public void onPublish(IMediaStream stream, String streamName, boolean isRecord, boolean isAppend)
		{
			System.out.println("onPublish[" + stream.getContextStr() + "]: streamName:" + streamName + " isRecord:" + isRecord + " isAppend:" + isAppend);
			try {
			
				getLogger().info("!!!  Response code: " + sendRequest(URL_START + "/?streamname=" + stream.getClient().getUri() + "/" + streamName + "&username=" +splitQuery(stream.getClient().getQueryStr()).get("user")));
			} catch (IOException e) {
				getLogger().info("!!! Some error during sending request on start event");
			}
		}
        
		public void onUnPublish(IMediaStream stream, String streamName, boolean isRecord, boolean isAppend)
		{
			System.out.println("onUnPublish[" + stream.getContextStr() + "]: streamName:" + streamName + " isRecord:" + isRecord + " isAppend:" + isAppend);
			try {
				getLogger().info("!!!  Response code: " + sendRequest(URL_STOP + "/?streamname=" + stream.getClient().getUri() + "/" + streamName + "&username=" +splitQuery(stream.getClient().getQueryStr()).get("user")));
			} catch (IOException e) {
				getLogger().info("!!! Some error during sending request on start event");
			}
		}
		
		public void onSeek(IMediaStream stream, double location)
		{
			System.out.println("onSeek[" + stream.getContextStr() + "]: location:" + location);
		}

		public void onStop(IMediaStream stream)
		{
			System.out.println("onStop[" + stream.getContextStr() + "]: ");
		}

		public void onCodecInfoAudio(IMediaStream stream,MediaCodecInfoAudio codecInfoAudio) {
			System.out.println("onCodecInfoAudio[" + stream.getContextStr() + " Audio Codec" + codecInfoAudio.toCodecsStr() + "]: ");
		}

		public void onCodecInfoVideo(IMediaStream stream,MediaCodecInfoVideo codecInfoVideo) {
			System.out.println("onCodecInfoVideo[" + stream.getContextStr() + " Video Codec" + codecInfoVideo.toCodecsStr() + "]: ");
		}
	}
	
	private int sendRequest(String urlString) throws IOException {
		URL url = new URL(urlString);
        HttpURLConnection con = (HttpURLConnection) url.openConnection();
        con.setRequestMethod("GET");
        con.setRequestProperty("User-Agent", USER_AGENT);
        getLogger().info("!!!  Sending request to: " + urlString);
        return con.getResponseCode();
	}
	
	public void onAppStart(IApplicationInstance appInstance)
	{
		this.appInstance = appInstance;
	}
	
	public void onStreamCreate(IMediaStream stream)
	{
		getLogger().info("onStreamCreate["+stream+"]: clientId:" + stream.getClientId());
		IMediaStreamActionNotify3 actionNotify = new StreamListener();

		WMSProperties props = stream.getProperties();
		synchronized (props)
		{
			props.put("streamActionNotifier", actionNotify);
		}
		stream.addClientListener(actionNotify);
	}

	public void onStreamDestroy(IMediaStream stream)
	{
		getLogger().info("onStreamDestroy["+stream+"]: clientId:" + stream.getClientId());

		IMediaStreamActionNotify3 actionNotify = null;
		WMSProperties props = stream.getProperties();
		synchronized (props)
		{
			actionNotify = (IMediaStreamActionNotify3) stream.getProperties().get("streamActionNotifier");
		}
		if (actionNotify != null)
		{
			stream.removeClientListener(actionNotify);
			getLogger().info("removeClientListener: " + stream.getSrc());
		}
	}
	
	private static Map<String, String> splitQuery(String query) throws UnsupportedEncodingException {
	    Map<String, String> query_pairs = new LinkedHashMap<String, String>();
	    String[] pairs = query.split("&");
	    for (String pair : pairs) {
	        int idx = pair.indexOf("=");
	        query_pairs.put(URLDecoder.decode(pair.substring(0, idx), "UTF-8"), URLDecoder.decode(pair.substring(idx + 1), "UTF-8"));
	    }
	    return query_pairs;
	}
}
